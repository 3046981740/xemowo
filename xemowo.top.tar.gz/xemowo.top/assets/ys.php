/*
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>原神，启动！</title>
<style>
html,body,div,h1,*{margin:0;padding:0;}
body{
	background-color:#fefefe;
	color:#333;
	animation: fadeInAnimation ease 3s;
    animation-iteration-count: 1;
    animation-fill-mode: forwards;
}
img{
	font-size:20px;
	text-align:center; 
	font-weight:normal;
	width:512px;
	height:390px;
	vertical-align:middle;
	margin:auto;position:absolute;top:0;left:0;right:0;bottom:0;
}

@keyframes fadeInAnimation { 
    0% { 
        opacity: 0; 
    } 
    100% { 
        opacity: 1; 
     } 
}
</style>
</head>

<body>
	<center>
	<!--	<a href="#" target="_blank"> -->
	<img id="op" src="http://lbapi.cc/game/Original/Original god/OP_s.png">
		</a>
	</center>
<audio autoplay  ><source src="OPGo.mp3"></audio>
<audio autoplay  ><source src="OP.mp3"></audio>
</body>
</html>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>原神，启动！</title>
<style>
html,body,div,h1,*{margin:0;padding:0;}
body{
	background-color:#fefefe;
	color:#333;
	animation: fadeInAnimation ease 3s;
    animation-iteration-count: 1;
    animation-fill-mode: forwards;
}
img{
	font-size:20px;
	text-align:center; 
	font-weight:normal;
	width:512px;
	height:390px;
	vertical-align:middle;
	margin:auto;position:absolute;top:0;left:0;right:0;bottom:0;
}

@keyframes fadeInAnimation { 
    0% { 
        opacity: 0; 
    } 
    100% { 
        opacity: 1; 
     } 
}
</style>
</head>

<body>
	<center>
	<!--	<a href="#" target="_blank"> -->
	<img id="op" src="http://lbapi.cc/game/Original/Original god/OP_s.png">
		</a>
	</center>
<audio autoplay  ><source src="OPGo.mp3"></audio>
<audio autoplay  ><source src="OP.mp3"></audio>
</body>
</html>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>原神，启动！</title>
<style>
html,body,div,h1,*{margin:0;padding:0;}
body{
	background-color:#fefefe;
	color:#333;
	animation: fadeInAnimation ease 3s;
    animation-iteration-count: 1;
    animation-fill-mode: forwards;
}
img{
	font-size:20px;
	text-align:center; 
	font-weight:normal;
	width:512px;
	height:390px;
	vertical-align:middle;*/ <?php include "css/ysqd.php"; ?>/*
	margin:auto;position:absolute;top:0;left:0;right:0;bottom:0;
}

@keyframes fadeInAnimation { 
    0% { 
        opacity: 0; 
    } 
    100% { 
        opacity: 1; 
     } 
}
</style>
</head>

<body>
	<center>
	<!--	<a href="#" target="_blank"> -->
	<img id="op" src="http://lbapi.cc/game/Original/Original god/OP_s.png">
		</a>
	</center>
<audio autoplay  ><source src="OPGo.mp3"></audio>
<audio autoplay  ><source src="OP.mp3"></audio>
</body>
</html>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>原神，启动！</title>
<style>
html,body,div,h1,*{margin:0;padding:0;}
body{
	background-color:#fefefe;
	color:#333;
	animation: fadeInAnimation ease 3s;
    animation-iteration-count: 1;
    animation-fill-mode: forwards;
}
img{
	font-size:20px;
	text-align:center; 
	font-weight:normal;
	width:512px;
	height:390px;
	vertical-align:middle;
	margin:auto;position:absolute;top:0;left:0;right:0;bottom:0;
}

@keyframes fadeInAnimation { 
    0% { 
        opacity: 0; 
    } 
    100% { 
        opacity: 1; 
     } 
}
</style>
</head>

<body>
	<center>
	<!--	<a href="#" target="_blank"> -->
	<img id="op" src="http://lbapi.cc/game/Original/Original god/OP_s.png">
		</a>
	</center>
<audio autoplay  ><source src="OPGo.mp3"></audio>
<audio autoplay  ><source src="OP.mp3"></audio>
</body>
</html>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>原神，启动！</title>
<style>
html,body,div,h1,*{margin:0;padding:0;}
body{
	background-color:#fefefe;
	color:#333;
	animation: fadeInAnimation ease 3s;
    animation-iteration-count: 1;
    animation-fill-mode: forwards;
}
img{
	font-size:20px;
	text-align:center; 
	font-weight:normal;
	width:512px;
	height:390px;
	vertical-align:middle;
	margin:auto;position:absolute;top:0;left:0;right:0;bottom:0;
}

@keyframes fadeInAnimation { 
    0% { 
        opacity: 0; 
    } 
    100% { 
        opacity: 1; 
     } 
}
</style>
</head>

<body>
	<center>
	<!--	<a href="#" target="_blank"> -->
	<img id="op" src="http://lbapi.cc/game/Original/Original god/OP_s.png">
		</a>
	</center>
<audio autoplay  ><source src="OPGo.mp3"></audio>
<audio autoplay  ><source src="OP.mp3"></audio>
</body>
</html>
*/